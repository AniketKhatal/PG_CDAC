//Write a cpp to print the askii val of the entered char

#include<iostream>
using namespace std;
int main(){
	char ch;
	cout<<"Enter the char that you want to print the askii value:";
	cin>>ch;
	cout<<int(ch)<<endl;
	return 0;
}
