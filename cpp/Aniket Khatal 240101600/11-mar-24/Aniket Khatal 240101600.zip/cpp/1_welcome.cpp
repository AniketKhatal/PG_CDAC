//To print the welcome

#include<iostream>
using namespace std;
int main(){
	cout<<"Welcome";
		return 0;
}
