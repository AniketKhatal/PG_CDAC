//WAP to program to add teo number and add into 3rd variable;

#include<iostream>
using namespace std;
int main(){
	int a;
	int b;
	int c;
	cout<<"Enter the value of a and b:";
	cin>>a>>b;
	c=a+b;
	cout<<c<<endl;
	return 0;
}
