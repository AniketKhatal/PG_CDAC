//WAP to print the datatype size

#include<iostream>
using namespace std;
int main(){
	int x;
	char ch;
	float f;
	double d;
	bool b;
	cout<<"The size of the int datatype :"<<sizeof(x)<<endl;
	cout<<"The size of the char datatype :"<<sizeof(ch)<<endl;
	cout<<"The size of the float datatype :"<<sizeof(f)<<endl;
	cout<<"The size of the double datatype :"<<sizeof(d)<<endl;
	cout<<"The size of the bool datatype :"<<sizeof(b)<<endl;
	return 0;
}
